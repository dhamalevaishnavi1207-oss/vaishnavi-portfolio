VAISHNAVI DHAMALE — PROJECT PORTFOLIO

Open index.html in a browser to preview the portfolio locally.
The website is a static HTML/CSS/JavaScript site and works without a backend.
Project downloads and images use relative paths, so keep the folders together.

To publish with GitHub Pages:
1. Create a new GitHub repository.
2. Upload index.html plus the assets/ and downloads/ folders.
3. In the repository, open Settings → Pages.
4. Choose Deploy from a branch, select main and /(root), then Save.
5. Wait for GitHub Pages to publish the site.

Notes:
- The duplicate carbon-footprint screenshot was included only once.
- The uploaded .env file and software installer were intentionally excluded.
- The class-task PDF is linked as a downloadable file; its content was not readable during portfolio preparation.
